// Google Maps API key
export const GOOGLE_MAPS_API_KEY = "AIzaSyDzxF9GEcPh8N4QiMYa0dbbXkQqmThRZMM";
